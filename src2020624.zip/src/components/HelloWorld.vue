<template>
  <div class="">


    <div class="wow  fadeInUp" data-wow-duration="2s" data-wow-delay="4s" data-wow-offset="10"   >这里的内容会有动画效果</div>

    <!-- <div class="animated fadeInUp hello"  animate-delay="1s" animate-duration="2s"> -->


      <h1>{{ msg }}</h1>
      <h2>Essential Links</h2>

    </div>
  </div>
</template>

<script>
import WOW from 'wowjs'
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  mounted(){
    new WOW.WOW().init()
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
