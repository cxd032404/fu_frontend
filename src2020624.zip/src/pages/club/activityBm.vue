<template lang="html">
  <div class="container-fluid jingpin_bg">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
          {{this.pagename}}
    </div>
    <div class="pb_top_zhanwei"></div>
      <br>
        <h2>进行中的活动</h2>
      <br>
      <div class="activy_run">
          <ul>

            <li v-for="item in onging"  >
              <div class="act_a fl">
                  <img :src="item.icon">
              </div>
              <div class="act_b fl">
                  <h4>{{item.club_name}}</h4>
                  <p>{{item.activity_name}}</p>
              </div>
              <div class="act_c fr">
                <p>{{item.chinese_end_date}}</p>
                <button  @click="toDetail(item.activity_id)" type="button" name="button">去报名</button>
              </div>
            </li>

          </ul>
      </div>
  </div>

</template>

<script>
export default {
  data(){
    return{
      pagename:'',
      onging:[],
    }
  },
  created() {
    this.getActivity();
  },
  mounted(){
  },
  methods:{

    toDetail(actid){

          this.$router.push({ name: 'activityBmDetail', params: { id: actid } });
      },

    getActivity(){
      var $this=this;
      var params={
        company:localStorage.getItem("company_id"),
        page_sign:"applyingAcitivity",
      }
      console.log(params);
      var qs = require('qs');
      var parm = JSON.stringify(params);
      // var parm = JSON.stringify(params);
      let url = this.api.userApi.get_zp
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
      .then((res) => {
        //顶部name
        console.log(res)
        this.pagename=res.data.data.pageInfo.page_name;
        console.log(res.data.data.pageElementList.applyingAcitivity.detail.activity_list);
        this.onging=res.data.data.pageElementList.applyingAcitivity.detail.activity_list

      }).catch((error) => {
        console.warn(error)
      })
    },

  }

}
</script>

<style lang="css" scoped>
</style>
