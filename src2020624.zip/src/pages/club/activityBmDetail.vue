<template lang="html">
  <div class="container-fluid jingpin_bg">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
        {{this.pagename}}
    </div>
    <div class="pb_top_zhanwei"></div>

    <div class="activity_banner container-fluid ">
          <img :src="banner_info.img_url">
    </div>
    <!-- //活动详情内容 -->
    <div class="activity_content container">
        <h1>{{acinfo.activity_name}}</h1>
        <p>{{acinfo.start_time}}-{{acinfo.update_time}}</p>
        <p>地点：{{adinfo.address}}</p>
        <p>报名时间{{acinfo.chinese_apply_start_time}}-{{acinfo.chinese_apply_end_time}}</p>
        <p>名额：{{acinfo.member_limit}}人</p>
        <p>活动介绍</p>
        <p>{{acinfo.comment}}</p>
    </div>

    <!-- 已报名 -->
    <div class="acvity_ybaom container">
        <div class="fl act_tx_list">
            <ul>
              <li v-for="item in uselist"  >
                <img v-if="item.user_img==null" src="@/assets/images/5959.png">
                <img v-else  :src="item.user_img">
              </li>
            </ul>
        </div>
        <div class="fr ac_num"  @click="toSignNum()">
          {{this.userlistnum}}人
        </div>
    </div>

    <!-- //报名按钮 -->

    <div class="jlb_baom container-fluid">
        <van-button @click="toBmCk()" type="primary" block>一键报名</van-button>
    </div>

    <!-- 报名状态变化 -->

    <div class="jlb_bm_code">
      <van-popup v-model="code_a">
        <div class="bm_cg_code tc">
            <img src="@/assets/images/codea.png">
            <br>
            <h1>报名成功</h1>

            <br>
            <p>点击确定，可返回上一步</p>
            <br>
              <van-button @click="to_code_a()" type="primary" block>确定</van-button>
        </div>
      </van-popup>
      <!-- 报名已满 -->
      <van-popup v-model="code_b">
        <div class="bm_cg_code tc">
            <img src="@/assets/images/worn.png">
            <br>
            <h1>报名失败</h1>
            <br>
            <p>对不起！该活动报名人数已满</p>
              <router-link  to="/activityBm" >
              <a href="javascript:void(0)" >去看看其他活动吧>>></a>
              </router-link>
            <br>
              <van-button @click="to_code_a()" type="primary" block>返回</van-button>
        </div>
      </van-popup>
      <!-- 报名失败 -->
      <van-popup v-model="code_c">
        <div class="bm_cg_code tc">
            <img src="@/assets/images/err.png">
            <br>
            <h1>报名失败</h1>
            <br>
            <p>对不起！该活动仅限俱乐部会员报名</p>
              <router-link  to="activityBm" >
                <a href="javascript:void(0)" >申请加入足球俱乐部>>></a>
              </router-link>
            <br>
              <van-button @click="to_code_a()" type="primary" block>返回</van-button>
        </div>
      </van-popup>


    </div>


  </div>
</template>

<script>
export default {
  data(){
    return{
      pagename:'',
      acinfo:'',
      adinfo:'',
      banner_info:[],
      activityid:this.$route.params.id,
      uselist:[],
      userlistnum:[],
      code_a:false,
      code_b:false,
      code_c:false,
    }
  },
  created() {
    this.getActivity();
    this.getTxlist();
    this.getBMlist();
  },
  mounted(){
  },
  methods:{


    toSignNum(actid){
          this.$router.push({ name: 'signupnum', params: { id: this.activityid } });
      },
    //报名成功三个状态
    to_code_a(){
      this.code_a=false;
      this.code_b=false;
      this.code_c=false;
    },
    //获取报名头像部分
    getBMlist(){
      var $this=this;
      var params={
        activity_id:this.$route.params.id,
        company:localStorage.getItem("company_id"),
        page_sign:"activityMemberList",
      }
      var qs = require('qs');
      var parm = JSON.stringify(params);
      // var parm = JSON.stringify(params);
      let url = this.api.userApi.get_zp
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
      .then((res) => {
        //顶部name
        console.log(res);
        this.pagename=res.data.data.pageInfo.page_name;
        this.uselist=res.data.data.pageElementList.activityMemberList.detail.activity_member_list;
        this.userlistnum=this.uselist.length;

      }).catch((error) => {
        console.warn(error)
      })
    },

      // 去报名
      toBmCk(){
        var $this=this;
        var params={
          activity_id:this.$route.params.id,
        }
        console.log(params);
        var qs = require('qs');
        var parm = JSON.stringify(params);
        // var parm = JSON.stringify(params);
        let url = this.api.userApi.jlb_bm
        this.axios.post(url,qs.stringify(params),)
        .then((res) => {
          //顶部name
          console.log(res);
          // 俱乐部报名三种状态
          if(res.data.code==200){
            this.code_a=true;
          }
          else if (res.data.code==400) {
            this.code_b=true;
          }
          else{
            this.code_c=true;
          }
          // console.log(res);
          // console.log(res.data.msg);
          this.$toast(res.data.msg);

        }).catch((error) => {
          console.warn(error)
        })
      },
    //
    getActivity(){
      var $this=this;
      var params={
        activity_id:this.$route.params.id,
        company:localStorage.getItem("company_id"),
        page_sign:"activityInfo",
      }
      console.log(params);
      var qs = require('qs');
      var parm = JSON.stringify(params);
      // var parm = JSON.stringify(params);
      let url = this.api.userApi.get_zp
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
      .then((res) => {
        //顶部name
        console.log(res);
        this.pagename=res.data.data.pageInfo.page_name;
        this.acinfo=res.data.data.pageElementList.activity_info.detail.activity_info;
        this.banner_info=res.data.data.pageElementList.activity_info.detail.club_info[0];
        this.adinfo=this.acinfo.checkin;
        console.log(this.acinfo);

      }).catch((error) => {
        console.warn(error)
      })
    },



    getTxlist(){
      var $this=this;
      var params={
        activity_id:this.$route.params.id,
        company:localStorage.getItem("company_id"),
        page_sign:"activityMemberList",
      }
      console.log(params);
      var qs = require('qs');
      var parm = JSON.stringify(params);
      // var parm = JSON.stringify(params);
      let url = this.api.userApi.get_zp
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
      .then((res) => {
        //顶部name
        console.log(res);

      }).catch((error) => {
        console.warn(error)
      })
    },




  }
}
</script>

<style lang="css" scoped>
</style>
