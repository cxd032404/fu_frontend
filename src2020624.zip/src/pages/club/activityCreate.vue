<template lang="html">
    <div class="container-fluid jingpin_bg">
      <div class="pb_tag_top">
        <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
          活动发布
      </div>
      <div class="pb_top_zhanwei"></div>

      <!-- //活动发布 -->
        <div class="activecrate container">

          <div class="huodongname">
            <input type="text" v-model="activityname" value=""  placeholder="请输入活动主题">
          </div>
            <div class="huodongmiaos">
              <van-field
                  v-model="message"
                  autosize
                  type="textarea"
                  placeholder="输入活动介绍，最多输入300个字符"
                />
            </div>

            <div class="club_from">
                  <label>
                    <div class="fl cb_tit">
                        俱乐部 <span>*</span>
                    </div>
                    <div class="fr cb_nr">
                        <div class="pb_sj_ty" @click="julebus()"  v-if="this.ismenber>1">
                            <input type="text" v-model="bm_jlb" readonly  >
                            <img src="@/assets/images/sanjsaaclucb.png">
                        </div>
                        <div class="pb_sj_ty"  v-else >
                            <input type="text" :value="julebu.club_name" readonly  >
                        </div>
                    </div>
                  </label>

                  <div class="bm_jlb" :class="{'bm_jlb_active':bmjlbTrue}">
                      <ul>
                        <li v-for="item in bmjlb"  v-text="item.club_name" @click="bm_jlb_Ck(item.club_name,item.club_id)"></li>
                      </ul>
                  </div>

                  <label>
                    <div class="fl cb_tit">
                        报名资格 <span>*</span>
                    </div>
                    <div class="fr cb_nr">
                        <div class="pb_sj_ty" @click="bmzgs()" >
                            <input type="text" v-model="bm_bmzg_value"  readonly  >
                            <img src="@/assets/images/sanjsaaclucb.png">
                        </div>
                    </div>
                  </label>
                  <div class="bm_bmzg" :class="{'bm_bmzg_active':bmzgTrue}">
                      <ul>
                        <li v-for="item in bmzg"  v-text="item.text" @click="bm_zg_Ck(item.text,item.value)"></li>
                      </ul>
                  </div>
                  <label>
                    <div class="fl cb_tit">
                        当月报名次数限制 <span>*</span>
                    </div>
                    <div class="fr cb_nr">
                        <div class="pb_sj_ty" @click="bmcss()">
                            <input type="text" v-model="bm_cishu" readonly >
                            <img src="@/assets/images/sanjsaaclucb.png">
                        </div>
                    </div>
                  </label>
                  <div class="bmcs_ct" :class="{'bmcs_ct_active':bmcsTrue}">
                      <ul>
                        <li v-for="item in bmcs"  v-text="item+'次'" @click="bm_cishu_Ck(item)"></li>
                      </ul>
                  </div>

                  <label>
                    <div class="fl cb_tit">
                        活动地点 <span>*</span>
                    </div>
                    <div class="fr hdplace" >
                      <input type="text" @click="positionCk()" v-model="mapaddress"  readonly>
                      <img @click="tomap()" src="@/assets/images/pos.png">
                    </div>
                  </label>
                  <!-- 活动地点下拉 -->
                  <div  class="hdplace_position" :class="{'hdplace_positionActive':hdplacepositionTrue}">
                    <ul>
                      <li   @click="posiPlaceCK(item.address,item.latitude,item.longitude)" v-for="(item,index) in recent"  :key="index" :value="item.address" v-text="item.address"></li>
                    </ul>
                  </div>


                  <label>
                    <div class="fl cb_tit">
                        活动时间 <span>*</span>
                    </div>
                    <div class="fr huodtime">
                      <span class="" v-model="starttimestr" v-text="starttime"></span>
                      <span class="" v-model="endtimestr" v-text="endtime"></span>
                        <img src="@/assets/images/ridas.png" @click="start()">
                    </div>
                  </label>
                  <label>
                    <div class="fl cb_tit">
                        报名起止时间 <span>*</span>
                    </div>
                    <div class="fr huodtime">
                      <span class="" v-model="bmstarttimestr" v-text="bmstarttime"></span>
                      <span class="" v-model="bmendtimestr" v-text="bmendtime"></span>
                        <img src="@/assets/images/ridas.png" @click="bmstart()">
                    </div>
                  </label>
                  <label>
                    <div class="fl cb_tit">
                        名额 <span>*</span>
                    </div>
                    <div class="fr cb_nr">
                      <input type="text" v-model="mingeinput"  placeholder="自定义名额"  @click="meselect()"/>
                    </div>
                  </label>

                  <!-- 名额下拉 -->
                  <div   class="minge" :class="{'mingeactive':ClassTrue}">
                    <ul>
                      <li   @click="mingliCk(item)" v-for="(item,index) in minge"  :key="index" :value="item" v-text="item"></li>
                    </ul>
                  </div>

            </div>

            <!-- 更多设置 -->
            <div class="moreshezhi" @click="moreshezhi()">
              更多设置
            </div>
            <div class="more_sz_cont" ref="moreht" :class="{'moreszcont_active':moreszcont_active_True}">
                <div class="gdhd">
                  <van-cell center title="每周固定活动">
                    <template #right-icon>
                      <van-switch v-model="hdchecked" size="24" />
                    </template>
                  </van-cell>
                </div>
                <div class="zdfabu">
                  <van-cell center title="自动发布设置"  @click="autotit_select_Ck()">
                    <input class="tr" disabled type="text"   v-model="autoname">
                  </van-cell>
                </div>
                <!-- 自动下拉 -->
                <div  class="autotit_select" :class="{'autotit_select_active':AutoStTrue}">
                  <ul>
                    <li v-for="(item,index) in fabutime"   @click="autoNameCk(item.time,index)" :key="index">{{item.time}}</li>
                  </ul>
                </div>
            </div>


            <!-- 发布按钮 -->
            <div class="fabu_button">
              <van-button type="primary" block @click="activitySend()">发布</van-button>
            </div>
            <!-- 开始时间控件 -->
           <van-popup v-model="starttimeshow" position="bottom">
             <van-datetime-picker
               v-model="currentDate"
               type="datetime"
               title="活动开始时间"
               :min-date="minDate"
               :max-date="maxDate"
               @confirm="confirm"
               @cancel="cancel"
             />
           </van-popup>
           <!-- 结束时间控件 -->
          <van-popup v-model="endtimeshow" position="bottom">
            <van-datetime-picker
              v-model="currentDate2"
              type="datetime"
              title="活动结束时间"
              :min-hour="0"
              :max-hour="24"
              @confirm="confirm1"
              @cancel="cancel1"
            />
          </van-popup>
          <!-- 报名开始事件 -->
         <van-popup v-model="bmstarttimeshow" position="bottom">
           <van-datetime-picker
             v-model="currentDate3"
             type="datetime"
             title="报名开始时间"
             :min-date="minDate"
             :max-date="maxDate"
             @confirm="confirm3"
             @cancel="cancel3"
           />
         </van-popup>
         <!-- 报名结束日期 -->
        <van-popup v-model="bmendtimeshow" position="bottom">
          <van-datetime-picker
            v-model="currentDate4"
            type="datetime"
            title="报名结束时间"
            :min-date="minDate"
            :max-date="maxDate"
            @confirm="confirm4"
            @cancel="cancel4"
          />
        </van-popup>



        </div>


    </div>
</template>

<script>
export default {
  data(){
    return{

      activityname:'',
      message:'',
      //活动主题
      mapaddress:localStorage.getItem("mapaddress"),
      value1: 0,
      bmjlb: [],
      zigevalue: 0,
      bm_jlb:"请选择俱乐部",
      bm_jlb_id:"",
      bmjlbTrue:false,
      bm_bmzg_code:'',
      bmzg: [
        { text: '仅限俱乐部会员', value: 0 },
        { text: '所有人', value: 1 },
      ],
      bm_bmzg_value:'仅限俱乐部会员',
      bmzgTrue:false,
      bm_bmzg:'篮球俱乐部',
      cishuvalue:0,
      bmcs:[],//报名次数
      bmcsTrue:false,
      bm_cishu:"1次",

      //活动时间
       minDate: new Date(),
       maxDate: new Date(2040, 12, 30),
       starttimeshow: false, //开始时间弹窗
       currentDate: new Date(), //开始标准时间
       currentDate2: new Date(), //开始标准时间
       starttimestr:'',
       starttime: "", //开始时间
       starttime1: "", //开始时间时间戳
       endtimestr:'',
       endtime: "", //开始时间
       endtime1: "", //开始时间时间戳
       //选择时间区间
       endtimeshow:false,
       currentTime: '12:00',
       //报名开始时间
       bmstarttimeshow:false,
       currentDate3: new Date(), //开始标准时间
       bmstarttime: "", //开始时间
       bmstarttimestr:"",
       bmstarttime1: "", //开始时间时间戳
       //报名结束时间
       bmendtimeshow:false,
       currentDate4: new Date(), //开始标准时间
       bmendtimestr:'',
       bmendtime: "", //开始时间
       bmendtime1: "", //开始时间时间戳
       minge:[],//名额数组
       ClassTrue:false,
       hdplacepositionTrue:false,
       recent:[],
       mingeinput:'',

       //活动cken
       hdchecked:true,
       checkid_code:'0',
       AutoStTrue:false,
       fabulist:[],
       fabutime:[
         {time:"星期一"},
         {time:"星期二"},
         {time:"星期三"},
         {time:"星期四"},
         {time:"星期五"},
         {time:"星期六"},
         {time:"星期日"},
       ],
       autoname:'星期一',
       //更多收起菜单
       moreszcont_active_True:false,

       //俱乐部管理员
       julebu:[],
       ismenber:'',
       julebuid:'',

    }
   },
  mounted(){
      this.get_Clup();
   },
   methods:{

    meselect(){
      this.ClassTrue = !this.ClassTrue;
    },
    mingliCk(item){
      alert(item);
      this.mingeinput=item;
      this.ClassTrue=false;
    },
    autotit_select_Ck(){
      this.AutoStTrue = !this.AutoStTrue;
    },
    positionCk(){
      this.hdplacepositionTrue=!this.hdplacepositionTrue;
    },
    autoNameCk(item,index){
       this.checkid_code=index;
      this.autoname=item;
      this.AutoStTrue=false;
    },
    bm_cishu_Ck(item){
      alert(item);
      this.bm_cishu=item+'次';
      this.bmcsTrue=false;
    },
    bm_zg_Ck(item,value){
      // alert(value);
      this.bm_bmzg_value=item;
      this.bmzgTrue=false;
    },
    bm_jlb_Ck(item,id){
      this.bm_jlb=item;
      this.bm_jlb_id=id;
      this.bmjlbTrue=false;
    },
    posiPlaceCK(item1,item2,item3){
      this.mapaddress=item1;
      localStorage.removeItem("locData")
      this.locData=
      {
        longitude:item3,
        latitude:item2,
        address:item1,
      }
      localStorage.setItem("locData",JSON.stringify(this.locData))
      this.hdplacepositionTrue=false;

    },
    moreshezhi(){
      this.moreszcont_active_True = !this.moreszcont_active_True;
    },
    //报名次数
    bmcss(){
      this.bmcsTrue = !this.bmcsTrue;
    },
    bmzgs(){
      this.bmzgTrue = !this.bmzgTrue;
    },
    julebus(){
      this.bmjlbTrue = !this.bmjlbTrue;
    },
     // 处理控件显示的时间格式
    start() {
      this.starttimeshow = true;
    },
     // 点击确定
    confirm() {
      this.starttimeshow = false;

      this.starttimestr=
      this.currentDate.getFullYear() +
      "-" +
      (Number(this.currentDate.getMonth()) + 1) +
      "-" +
      this.currentDate.getDate() +
      " " +
      this.currentDate.getHours() +
      ":" +
      this.currentDate.getMinutes()+
      ":" +
      this.currentDate.getSeconds();
      // alert(this.starttimestr);
      //展示日期
      this.starttime =
        this.currentDate.getFullYear() +
        "/" +
        (Number(this.currentDate.getMonth()) + 1) +
        "/" +
        this.currentDate.getDate() +
        "/" +
        this.currentDate.getHours() +
        ":" +
        this.currentDate.getMinutes();
        this.starttime1 = new Date(this.currentDate).getTime() / 1000;
        this.endtimeshow=true

    },
    //活动结束时间
    confirm1() {
      this.endtimeshow = false;
      this.endtimestr=
      this.currentDate2.getFullYear() +
      "-" +
      (Number(this.currentDate2.getMonth()) + 1) +
      "-" +
      this.currentDate2.getDate() +
      " " +
      this.currentDate2.getHours() +
      ":" +
      this.currentDate2.getMinutes()+
      ":" +
      this.currentDate2.getSeconds();
      // alert(this.endtimestr);

      this.endtime=
      "-" +
      this.currentDate2.getHours() +
      ":" +
      this.currentDate2.getMinutes()+
      ":" +
      this.currentDate2.getSeconds();

    },
    bmstart() {
      this.bmstarttimeshow = true;
    },
    //报名开始时间
    confirm3() {
      this.bmstarttimeshow = false;
      this.bmstarttimestr=
      this.currentDate3.getFullYear() +
      "-" +
      (Number(this.currentDate3.getMonth()) + 1) +
      "-" +
      this.currentDate3.getDate() +
      " " +
      this.currentDate3.getHours() +
      ":" +
      this.currentDate3.getMinutes()+
      ":" +
      this.currentDate3.getSeconds();

      // 显示时间
      this.bmstarttime =
        (Number(this.currentDate3.getMonth()) + 1) +
        "/" +
        this.currentDate3.getDate() +
        "/" +
        this.currentDate3.getHours() +
        ":" +
        this.currentDate3.getMinutes();

        this.bmstarttime1 = new Date(this.currentDate3).getTime() / 1000;
        alert(this.bmstarttime);
        this.bmendtimeshow = true;
    },
    confirm4() {
      this.bmendtimeshow = false;

      this.bmendtimestr=
      this.currentDate4.getFullYear() +
      "-" +
      (Number(this.currentDate4.getMonth()) + 1) +
      "-" +
      this.currentDate4.getDate() +
      " " +
      this.currentDate4.getHours() +
      ":" +
      this.currentDate4.getMinutes()+
      ":" +
      this.currentDate4.getSeconds();

      //显示的时间
       this.bmendtime =
        "—" +
        (Number(this.currentDate4.getMonth()) + 1) +
        "/" +
        this.currentDate4.getDate() +
        "/" +
        this.currentDate4.getHours() +
        ":" +
        this.currentDate4.getMinutes();
        this.bmendtime1 = new Date(this.currentDate4).getTime() / 1000;
    },
    //点击取消
    cancel(){
        this.starttimeshow = false;
    },
    cancel1(){
      this.endtimeshow = false;
    },
    cancel3(){
        this.bmstarttimeshow = false;
    },
    cancel4(){
      this.bmendtimeshow = false;
    },

    //获取地图地址
     tomap(){
        this.$router.push({
          name:"map"
        })
     },
     get_Clup(){
       //上拉刷新初始化
       var $this=this;
       var company_id =  localStorage.getItem("company_id");
       var params={
         company:company_id,
         page_sign:this.$route.name,
       }
       console.log(params);

       var qs = require('qs');
       var parm = JSON.stringify(params);
       let url = this.api.userApi.get_zp
       this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
       .then((res) => {
         console.log(res);
         console.log(res.data.data.pageElementList)
         this.minge=res.data.data.pageElementList.acitvityCreate.detail.member_limit;
         this.bmcs=res.data.data.pageElementList.acitvityCreate.detail.monthly_apply_limit;
         // 俱乐部会员
         // 判断是否超级管理员
         this.ismenber=res.data.data.pageElementList.acitvityCreate.detail.user_club_list.length;
         this.julebu=res.data.data.pageElementList.acitvityCreate.detail.user_club_list;
         this.bmjlb=res.data.data.pageElementList.acitvityCreate.detail.user_club_list;
         // this.bm_jlb=res.data.data.pageElementList.acitvityCreate.detail.user_club_list[0].club_name;
         console.log(this.julebu);
         // this.julebuid=this.julebu.club_id;
         this.recent=res.data.data.pageElementList.acitvityCreate.detail.recent_position_list;
       }).catch((error) => {
         console.warn(error)
       })

     },
     // 活动发布提交
     activitySend(){
       var $this=this;
       var company_id =  localStorage.getItem("company_id");
       // 判断是否俱乐部会员或者所有人
       if(this.bm_bmzg_value=="仅限俱乐部会员"){
         this.bm_bmzg_code=1;
       }
       else{
         this.bm_bmzg_code=0;
       }
       //更多设置判断是否重复
       if(this.hdchecked==false){
         this.checkid_code="-1";
       }
       var params={
         company:company_id,
         activity_name:this.activityname,
         club_id:this.bm_jlb_id,
         comment:this.message,
         member_limit:this.mingeinput,
         monthly_apply_limit:this.bm_cishu,
         start_time:this.starttimestr,
         end_time:this.endtimestr,
         apply_start_time:this.bmstarttimestr,
         apply_end_time:this.bmendtimestr,
         club_member_only:this.bm_bmzg_code,
         checkin:localStorage.getItem("locData"),
         weekly_rebuild:this.checkid_code,
       }

        console.log(params);
       var qs = require('qs');
       // var parm = JSON.stringify(params);
       let url = this.api.userApi.activitySd
       this.axios.post(url,qs.stringify(params),)
       .then((res) => {
         console.log(res);

         // 返回MSG提示
         this.$toast(res.data.msg);

       }).catch((error) => {
         console.warn(error)
       })

     }

   }
  }
</script>

<style lang="css" scoped>
</style>
