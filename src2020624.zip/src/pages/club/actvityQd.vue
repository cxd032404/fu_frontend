<template lang="html">
  <div class="container-fluid jingpin_bg">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
        {{this.pagename}}
    </div>
    <div class="pb_top_zhanwei"></div>
    <div class="container">
      <van-tabs v-model="active">
        <van-tab title="待签到">
            <div class="act_qd_list">
                <ul>
                  <li @click="toqdDetail(item.activity_id)" v-for="item in no_list"  >
                    <!-- <img :src="item.icon" alt=""> -->
                    <img v-if="item.icon==''" src="@/assets/images/5959.png">
                    <img v-else  :src="item.icon">
                    <span>{{item.activity_name}}</span>
                  </li>
                </ul>
            </div>
        </van-tab>
        <van-tab title="已报名">

            <div class="jlb_ybm">
                <ul>
                  <li v-for="item in yes_list"  >
                    <div class="fl jlb_ybm_a">
                      <img v-if="item.icon==''" src="@/assets/images/5959.png">
                      <img v-else  :src="item.icon">
                    </div>
                    <div class="fl">
                        <h1>{{item.club_name}}</h1>
                        <p>{{item.position}}</p>
                        <p>time:{{item.start_time}} -- {{item.end_time}}</p>
                        <p>已报名人数{{item.Usercount}}</p>
                    </div>
                  </li>

                </ul>
            </div>

        </van-tab>
      </van-tabs>
    </div>


    <!-- 待签到弹窗 -->
    <div class="wqiandao_dislog">
          <van-popup v-model="dis_show">
            <div class="wqiandao_dislog_ct">
              <h1>签到任务</h1>
              <h2>热爱足球永不熄灭</h2>
              <p>提醒各位会员，下午18：00有活动，请准时到场签到</p>
              <div class="">
                <p>源深体育中心</p>
                <p>6月5日 18:00 - 20：00</p>
              </div>
              <p>已签到人数：3人</p>
              <van-button type="primary" block>去签到</van-button>
            </div>
          </van-popup>
    </div>


  </div>
</template>

<script>
export default {
  data(){
    return{
      active: 0,
      dis_show: false,
      pagename:'',
      //未签到
      no_list:[],
      //所有的
      yes_list:[],
    }
  },
  created() {
  },
  beforeDestroy(){

 },
  mounted(){
    this.getActivity();
    this.getHdlist();
  },
  methods:{
    toqdDetail(actid){
        this.$router.push({ name: 'actvityQdDetail', params: { id: actid } });
    },
    getActivity(){
      var $this=this;
      var params={
        company:localStorage.getItem("company_id"),
        page_sign:"appliedActivityList",
        status:"0",
      }
      console.log(params);
      var qs = require('qs');
      var parm = JSON.stringify(params);
      // var parm = JSON.stringify(params);
      let url = this.api.userApi.get_zp
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
      .then((res) => {
        //顶部name
        console.log(res);
        this.no_list=res.data.data.pageElementList.activitylist.detail.activity_list;

      }).catch((error) => {
        console.warn(error)
      })
    },

    getHdlist(){
      var $this=this;
      var params={
        company:localStorage.getItem("company_id"),
        page_sign:"appliedActivityList",
        status:"2",
      }
      console.log(params);
      var qs = require('qs');
      var parm = JSON.stringify(params);
      // var parm = JSON.stringify(params);
      let url = this.api.userApi.get_zp
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
      .then((res) => {
        //顶部name
        console.log(res);
        this.pagename=res.data.data.pageInfo.page_name;
        this.yes_list=res.data.data.pageElementList.activitylist.detail.activity_list;

      }).catch((error) => {
        console.warn(error)
      })
    },



  },

}
</script>

<style lang="css" scoped>
</style>
