<template lang="html">
  <div class="container-fluid jingpin_bg">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
        活动签到
    </div>
    <div class="pb_top_zhanwei"></div>

    <div class="jlb_qd_map_ct">
        <p>2020年6月5日</p>
        <p>足球俱乐部活动</p>
        <p>当前位置：{{locData.address}}</p>
    </div>

    <div class="demo-input-suffix" >
        <!-- <el-link type="info">关键词：</el-link><el-input  class="lineinput"   size="mini" v-model="keyword"></el-input><br>
        <el-link type="info">地  区：</el-link><el-input  class="lineinput"  size="mini" v-model="location"></el-input><br>
        <el-link type="info">l n g：</el-link><el-input  class="lineinput"  size="mini" v-model.number="locData.longitude"></el-input><br>
        <el-link type="info">l a t：</el-link><el-input  class="lineinput"  size="mini" v-model.number="locData.latitude"></el-input><br>
        <el-link type="info">地  址：</el-link><el-input  class="lineinput"   size="mini" v-model="locData.address"></el-input> -->
    </div>
    <div class="post_dw_map">
      <input v-model.number="locData.longitude">
      <input v-model.number="locData.latitude">
      <input v-model.number="this.zoom">
      <input v-model.number="locData.address">
      <baidu-map
          class="map"
          :dragging="false"
          :scroll-wheel-zoom="true"  @ready="mapReady"
          :center="center"  :autoLocation="true"
          :zoom="zoom"     ak="NI5YPG5rt4bWlt6AmLoFuOIos88uM53C"
          @moving="syncCenterAndZoom"
          @moveend="syncCenterAndZoom"
          @zoomend="syncCenterAndZoom">
           <bm-geolocation anchor="BMAP_ANCHOR_BOTTOM_RIGHT" :showAddressBar="false" :autoLocation="true" @locationSuccess="getLoctionSuccess">
           </bm-geolocation>
          <bm-marker :position="{lng: center.lng, lat: center.lat}" :dragging="false" animation="BMAP_ANIMATION_BOUNCE" :icon="{url: 'http://developer.baidu.com/map/jsdemo/img/fox.gif', size: {width: 300, height: 157}}"></bm-marker>
      </baidu-map>


    </div>

    <!-- 签到状态 -->

    <div class="map_code">
          <div  v-show="mapcodea" class="map_code_a tc" @click="dianjiqiandao()">
              <div class="map_code_1">
                <div class="map_code_pos">
                  <h3>签到</h3>
                  <p>  {{this.nowTime}}</p>
                </div>
              </div>
              <p>你已进入有效打卡区域内</p>
          </div>

          <div v-show="mapcodeb" class="map_code_a tc" >
              <div class="map_code_2">
                <div class="map_code_pos">
                  <h3>无法签到</h3>
                  <p>  {{this.nowTime}}</p>
                </div>
              </div>
              <p>管理员设置打卡区域在500m内</p>
          </div>

          <div v-show="mapcodec" class="map_code_a tc">
              <div class="map_code_3">
                <div class="map_code_pos">
                  <h3>签到成功</h3>
                  <p>  {{this.nowTime}}</p>
                </div>
              </div>
              <p>您已进入有效活动时间内</p>
          </div>

    </div>


    </div>
</template>

<script>
import {BaiduMap,BmNavigation,BmView,BmGeolocation,BmCityList,BmMarker} from 'vue-baidu-map'
    export default {
        components: {
            BaiduMap,
            BmNavigation,
            BmView,
            BmGeolocation,
            BmMarker,
            BmCityList
        },
        data () {
            return {
              center: {lng: '0',lat: '0'},
              zoom: 15,
              locData:{
                  longitude:'',
                  latitude:'',
                  address:'',
              },
              timer:null, //定时器名称
              mapcodea:false,
              mapcodeb:false,
              mapcodec:false,
              nowDate: "",    // 当前日期
              nowTime: "",    // 当前时间
              nowWeek: "",     // 当前星期
              temp:{},
            }
        },
      mounted() {
          this.currentTime();

          this.getQdao();
          // this.queryInfo();
          this.timer = setInterval(() => {
               setTimeout(this.queryInfo, 0)
           }, 5000)

        },

        created() {
        },
    // 销毁定时器
        beforeDestroy(){
         clearInterval(this.timer);
         this.timer = null;
         //显示当前日期实时更新
         if (this.getDate) {
             console.log("销毁定时器")
             clearInterval(this.getDate); // 在Vue实例销毁前，清除时间定时器
         }
       },
        methods: {
          //vue每隔五分钟刷新下网页获取实时定位
          queryInfo(){
           //do something
             // location.reload()
          },
          syncCenterAndZoom (e) {
            const {lng, lat} = e.target.getCenter()
            this.center.lng = lng
            this.center.lat = lat
            // this.zoom = e.target.getZoom()
          },
          mapReady ({ BMap, map }) {
             const _this = this
             // 获取自动定位方法
             var geolocation = new BMap.Geolocation()
             // 获取逆解析方法实例
             this.myGeo = new BMap.Geocoder()

             // 获取自动定位获取的坐标信息
             geolocation.getCurrentPosition(
               function (r) {
                 console.log(r);
                 _this.center = {
                   lng: r.point.lng,
                   lat: r.point.lat
                 }
                 _this.point = {
                   lng: r.point.lng,
                   lat: r.point.lat
                 }

                 //根据坐标获取地址信息
                 var point = new BMap.Point(r.point.lng, r.point.lat);
                 var gc = new BMap.Geocoder();
                 gc.getLocation(point, function (rs) {
                     var addComp = rs.addressComponents;
                     console.log(rs);//地址信息
                     _this.locData.address = rs.address;
                     _this.locData.longitude = rs.point.lng;
                     _this.locData.latitude = rs.point.lat;

                    // _this.temp = rs.point
                     localStorage.setItem("locDataMap",JSON.stringify(_this.locData))

                 });

               },
               { enableHighAccuracy: true }
             )
             //

           },

           //定位成功回调
           getLoctionSuccess(){

           },

           //点击签到提示签到成功
           dianjiqiandao(){
             this.mapcodea=false
             this.mapcodeb=false
             this.mapcodec=true
           },
          //获取签到校验
          getQdao(){
            var $this=this;

            console.log(this.locData)
            console.log(this.locData.valueOf(0))
            // console.log(this.locData)

            return
            // console.log( JSON.parse(JSON.stringify(this._locData)))
            var params={
              activity_id:this.$route.params.id,
              position:localStorage.getItem("locDataMap"),
            }
            console.log(params);
            // return
            var qs = require('qs');
            // var parm =
            let url = this.api.userApi.jlb_qd_map
            this.axios.post(url,qs.stringify(params),)
            .then((res) => {
              //顶部name
              console.log(res);
              if(res.data.code==400){
                this.mapcodeb=true
              }
              else{
                this.mapcodea=true
              }

            }).catch((error) => {
              console.warn(error)
            })
          },

          //获取当前时间
          currentTime() {
            setInterval(this.getDate, 500);
            },
           getDate: function() {
                var _this = this;
                let yy = new Date().getFullYear();
                let mm = new Date().getMonth() + 1;
                let dd = new Date().getDate();
                let week = new Date().getDay();
                let hh = new Date().getHours();
                let mf =
                    new Date().getMinutes() < 10
                        ? "0" + new Date().getMinutes()
                        : new Date().getMinutes();
                if (week == 1) {
                    this.nowWeek = "星期一";
                } else if (week == 2) {
                    this.nowWeek = "星期二";
                } else if (week == 3) {
                    this.nowWeek = "星期三";
                } else if (week == 4) {
                    this.nowWeek = "星期四";
                } else if (week == 5) {
                    this.nowWeek = "星期五";
                } else if (week == 6) {
                    this.nowWeek = "星期六";
                } else {
                    this.nowWeek = "星期日";
                }
                _this.nowTime = hh + ":" + mf;
                _this.nowDate = yy + "/" + mm + "/" + dd;
            }


        },


    }

</script>
<style>
.map {
  width: 100%;
  height: 300px;
}
.BMap_cpyCtrl {
   display: none;
 }
.anchorBL {
   display: none;
}
</style>
