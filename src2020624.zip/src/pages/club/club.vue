<template lang="html">
    <div class="container-fluid jingpin_bg">
      <div class="pb_tag_top">
        <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
          俱乐部
      </div>
      <div class="pb_top_zhanwei"></div>

        <!-- <van-cell title="活动发布" is-link to="activityCreate" />
        <van-cell title="活动管理" is-link to="managedActivityList" />
        <van-cell title="会员管理" is-link to="vipMenber" />
        <van-cell title="活动报名" is-link to="activityBm" />
        <van-cell title="活动签到" is-link to="actvityQd" /> -->

      <div class="jianbuzou_pic">
          <img src="@/assets/images/1.png" alt="">
      </div>

    </div>
</template>

<script>
export default {
  data(){
    return{}
    },
    mounted(){
   },
   methods:{

   }
  }
</script>

<style lang="css" scoped>
</style>
