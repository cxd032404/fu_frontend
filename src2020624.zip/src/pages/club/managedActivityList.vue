<template lang="html">
  <div class="container-fluid jingpin_bg">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
        活动管理
    </div>
    <div class="pb_top_zhanwei"></div>

    <!-- 管理才有的下拉框 -->
    <div class="gly_zhs container" v-if="this.managed_list.length>1">
        <div class="gly_zhs_input" @click="gly_zhs_inputCk()">
            <van-field v-model="jlb_name"     clearable  />
        </div>
        <div class="act_gl_se"  :class="{'act_gl_se_active':act_gl_seTrue}">
            <ul>
              <li @click="zhsinput(item.club_name,item.club_id)" v-for="(item,index) in managed_list"  :key="index">{{item.club_name}}</li>
            </ul>
        </div>
    </div>
    <div v-else>
    </div>
    <!-- 李彪开始 -->
      <div class="cb_ac_list container">

        <!-- 上拉加载 -->
        <van-list
           v-model="loading"
          :immediate-check="false"
           :offset="100"
           :finished="finished"
           finished-text="没有更多内容了"
            @load="loadMore"
            ref="fenye_list"
          >

          <ul>
            <li v-for="(item,index) in fenye_list"  :key="index" @click="toDetail(item.activity_id)">
              <div class="fl cb_ac_list_ico">
                <img :src="item.icon">
              </div>
              <div class="fl cb_ac_list_name">
                  {{item.club_name}}
              </div>
              <div class="fr cb_ac_list_jt">
                <img src="@/assets/images/rscopy.png">
              </div>
              <div class="fr cb_ac_list_time">
                  {{item.start_time}}
              </div>
            </li>
          </ul>

          </van-list>


      </div>

  </div>
</template>

<script>
export default {

  data(){
    return{
      activity_list:[],
      jlb_name:'俱乐部分类',
      act_gl_seTrue:false,
      managed_list:[],
      clubid:'',
      // 上拉加载分页
      loading: false,
      finished: false,
      pageNum:1,
      pageSize:5,
      fenye_list:[],
      result_zta:"",
    }
  },

  created() {
    this.getActivity()
  },
  mounted(){
  },
  methods:{


    toDetail(actid){
          this.$router.push({ name: 'managedActivityListDetail', params: { id: actid } });
      },
    // 管理员部分下拉
    gly_zhs_inputCk(){
        this.act_gl_seTrue = !this.act_gl_seTrue;
    },
    zhsinput(name,id){
      this.jlb_name=name;
      this.act_gl_seTrue=false;
      this.clubid=id;
      //筛选分别俱乐部内容
      this.pageNum=1,
      this.loading = false;
      this.finished = false;
      this.fenye_list=[];
      this.getActivity();
    },
    // mingliCk(item){
    //   alert(item);
    //   this.mingeinput=item;
    //   this.ClassTrue=false;
    // },
    //参加活动列表
      getActivity(){
        var $this=this;
        var params={
          company:localStorage.getItem("company_id"),
          page_sign:this.$route.name,
          pageSize:this.pageSize,
          page:this.pageNum,
          club_id:this.clubid,
        }
        console.log(params);
        var qs = require('qs');
        var parm = JSON.stringify(params);
        // var parm = JSON.stringify(params);
        let url = this.api.userApi.get_zp
        this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),)
        .then((res) => {
          console.log(res);
          // console.log(res.data.data.pageElementList.activitylist.detail.activity_list);
          this.activity_list=res.data.data.pageElementList.managedActivityList.detail.managed_activity_list;
          this.fenye_list=this.fenye_list.concat(this.activity_list);
          //状体判断
          // this.result_list
          this.managed_list=res.data.data.pageElementList.managedActivityList.detail.managed_club_list;
          this.result_zta=res.data.data.pageElementList.managedActivityList.detail.residuals;
          // console.log(this.fenye_list);
          // 返回MSG提  this.loading = false;
           this.loading = false;
            if(this.result_zta==0){
              this.finished = true;
            }
          // // this.$toast(res.data.msg);
        }).catch((error) => {
          console.warn(error)
        })
      },
      //上拉加载
      loadMore() {
        this.pageNum++;
        this.getActivity();
      },

  }


}
</script>

<style lang="css" scoped>
</style>
