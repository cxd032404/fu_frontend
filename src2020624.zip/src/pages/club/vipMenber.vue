<template lang="html">
  <div class="container-fluid jingpin_bg">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
        会员管理
    </div>
    <div class="pb_top_zhanwei"></div>
    <div class="club_hy_meber">
          <div class="hy_meber_top">
            <ul>
              <li class="active">待审核</li>
              <li>已审核</li>
            </ul>
          </div>

          <van-button type="primary" @click="checkAll">全选</van-button>
          <van-button type="info" @click="toggleAll">反选</van-button>
          <div class="hy_meber_dsh">

            <van-checkbox-group v-model="result"  ref="checkboxGroup">
              <ul>
                <li>
                  <div class="fl dhs_a">
                        <van-checkbox name="a"></van-checkbox>
                  </div>
                  <div class="fl dhs_b">
                     <h1>张三 <span>2020/6/00 15:48</span> </h1>
                     <p>申请加入:足球俱乐部</p>
                  </div>
                </li>
                <li>
                  <div class="fl dhs_a">
                      <van-checkbox name="b"></van-checkbox>
                  </div>
                  <div class="fl dhs_b">
                     <h1>张三 <span>2020/6/00 15:48</span> </h1>
                     <p>申请加入:足球俱乐部</p>
                  </div>
                </li>
                <li>
                  <div class="fl dhs_a">
                        <van-checkbox name="c"></van-checkbox>
                  </div>
                  <div class="fl dhs_b">
                     <h1>张y <span>2020/6/00 15:48</span> </h1>
                     <p>申请加入:足球俱乐部</p>
                  </div>
                </li>
                <li>
                  <div class="fl dhs_a">
                      <van-checkbox name="d"></van-checkbox>
                  </div>
                  <div class="fl dhs_b">
                     <h1>张p <span>2020/6/00 15:48</span> </h1>
                     <p>申请加入:足球俱乐部</p>
                  </div>
                </li>

              </ul>
            </van-checkbox-group>

          </div>


          <van-button type="primary" @click="tongguo()">通过</van-button>
          <van-button type="info" @click="jujue()">拒绝</van-button>



    </div>

  </div>
</template>

<script>
export default {
  data(){
    return{
      result: [],
    }
  },
  methods: {
    checkAll() {
      this.$refs.checkboxGroup.toggleAll(true);
    },
    toggleAll() {
      this.$refs.checkboxGroup.toggleAll();
    },

    tongguo(){
      alert(1);
      console.log(this.result);
    }
  },
}
</script>

<style lang="css" scoped>
</style>
