<template lang="html">

</template>

<script>

export default {
  data() {
    return {

    }
  },
  created(){

  },
  mounted() {

  },
  methods: {
  }

}
</script>

<style lang="css" scoped>
</style>
