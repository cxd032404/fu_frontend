<template lang="html">
    <div class="">
        <div class="yuefen">
          <ul>
            <li v-bind:class='{yueActive:index==yuefenTrue}' v-for="(item,index) in yuefen"  :key="index" @click="yuefenCon(index);">
              {{item.name}}
            </li>
          </ul>
        </div>

        <div class="day">
          <ul>
            <li v-bind:class='{dayactive:index==ClassTrue}' v-for="(item,index) in dayslist" :key="index"  @click="daysClick(index)">
              {{item}}
            </li>
          </ul>
        </div>
    </div>
</template>

<script>
export default {
  data(){
    return{
      yuefen:[
        {name:'January',id:'1'},
        {name:'February',id:'2'},
        {name:'March',id:'3'},
        {name:'April',id:'4'},
        {name:'May',id:'5'},
        {name:'June',id:'6'},
        {name:'July',id:'7'},
        {name:'August',id:'8'},
        {name:'September',id:'9'},
        {name:'October',id:'10'},
        {name:'November',id:'11'},
        {name:'December',id:'12'},
      ],
      days:[],
      daylth:"1",
      //日期绑定当前天数
      ClassTrue:'-1',
      yuefenTrue:'',
      onmouths:'',
      ondays:'',
      allmh:[],
      dayslist:[],
      //ceshi
      alldaylist:[],
    }
  },
  mounted(){
    this.getMouth();
  },
  methods: {

    //获取当前月份天数
      getMouth(){
        for(var m=1;m<=this.yuefen.length;m++){
            var datas=new Date(2020,m,0).getDate()
            this.allmh=this.allmh.concat(datas);
        }
        //获取每个月天数
        // console.log(this.allmh);
        // var newCa=[]
        for(var n=0;n<this.allmh.length;n++){
           var dayca=[]
            for (var m = 1;m <=this.allmh[n]; m++) {
              dayca.push(m)
            }
            var param={
              allDay:this.allmh[n],
              Mouth:this.yuefen[n],
              arr:dayca
            }
            // console.log(param);
            this.alldaylist.push(param)
        }
          // this.alldaylist=this.alldaylist.concat(this.alldaylist);
          console.log(this.alldaylist)

          //选中当前月份和天数
          var nowData=new Date().getMonth()
          this.yuefenTrue=nowData;
          this.dayslist=this.alldaylist[nowData].arr;


      },
      //点击月份切换当前天数
      yuefenCon(index){
        this.dayslist=this.alldaylist[index].arr;
        console.log(this.dayslist);
        this.yuefenTrue=index;
      },
      daysClick(index){
        alert(index+1);
      },
      //绑定当前天数的事件
      // 2020-1-15

  }
}
</script>

<style lang="css" scoped>
</style>
