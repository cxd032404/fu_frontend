<template lang="html">
  <div class="container-fluid">
    <div class="pb_tag_top">
      <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
        {{pagenamess.page_name}}
    </div>
    <div class="pb_top_zhanwei"></div>

    <div class="contant_img">
      <img :src="honor_detail.img_url" alt="">
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      pagenamess:[],
      honor_detail:[],
    }
  },
  created() {
    this.detail()
  },
  methods:{
    // 内容页点赞
    //
    detail(){
      var $this=this;
      var company_id =  localStorage.getItem("company_id");
      var params={
        company:company_id,
        page_sign:this.$route.name,
        post_id:this.$route.query.id,
      }
      var qs = require('qs');
      var parm = JSON.stringify(params);
      let url = this.api.userApi.rongyu_list
      this.axios.post(url+'/'+params.company+'/'+params.page_sign,qs.stringify({params:parm}),{headers:{'Accept': 'application/json','UserToken': window.localStorage.getItem("token")}})
      .then((res) => {

        this.pagenamess=res.data.data.pageInfo;
          console.log(this.pagenamess);
        this.honor_detail=res.data.data.pageElementList.contactus.detail;

      }).catch((error) => {
        console.warn(error)
      })
    },

  }

}
</script>

<style lang="css" scoped>
</style>
