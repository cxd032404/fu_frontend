<template lang="html">
    <div class="container-fluid jingpin_bg">
      <div class="pb_tag_top">
        <span><a href="javascript:history.go(-1)" class="back"><img src="@/assets/images/arrow-lift.png"></a></span>
          健步走
      </div>
      <div class="pb_top_zhanwei"></div>


      <div class="jianbuzou_pic">
          <img src="@/assets/images/1.png" alt="">
      </div>

    </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
</style>
